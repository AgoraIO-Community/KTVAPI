package io.agora.ktvapi.soul;

public class IRoomCallback {
    public void onLocalAudioStateChanged(int state) {
    }
}
