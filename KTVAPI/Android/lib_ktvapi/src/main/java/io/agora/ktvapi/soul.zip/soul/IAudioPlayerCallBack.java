package io.agora.ktvapi.soul;

public class IAudioPlayerCallBack {
    public void onAudioPositionChanged(String s, long currentAudioPosition, String audioUniId, boolean b) {
    }
}
